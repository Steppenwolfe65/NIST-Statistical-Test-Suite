extern double erf(const double);
extern double erfc(const double);